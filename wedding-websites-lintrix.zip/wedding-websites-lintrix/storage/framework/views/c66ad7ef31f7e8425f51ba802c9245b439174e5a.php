<div data-page="wish" class="page no-toolbar no-navbar hidden" id="wish">
    <div class="page-content">
        <div id="pages_maincontent">
            <div class="page_single layout_fullwidth_padding" style="width: 100%;margin: 0px;text-align: center;" >
                <img src="<?php echo e(asset('wedding-1/images/headers/top/7.png')); ?>" alt="" width="100%" style="display: inline-block;"  >
            </div>
            <div id="says_content" class="page_single layout_fullwidth_padding">
                <h2 class="page_title">
                    <strong>Ucapan Do`a</strong>
                </h2>
                <h2 id="Note"></h2>
                <div class="contactform">
                    <div class="contactform">
                        <?php echo e(Form::open(['route'=>'send-wish.wedding-1','role'=>'form','enctype'=>'multipart/form-data'])); ?>

                            <?php echo e(Form::hidden('customer_id', $id, ['id'=>'customer_id'])); ?>

                            <?php echo e(Form::label('nama', 'Nama :',[''])); ?>

                            <?php echo e(Form::text('nama', '',["id"=>"nama","class"=>"form_input","required"=>"required"])); ?>

                            <?php echo e(Form::label('wish', 'Ucapan :',[''])); ?>

                            <?php echo e(Form::textarea('wish', '', ['class'=>'form_textarea textarea','rows'=>'','cols'=>'','required'=>'required'])); ?>

                            <?php echo e(Form::submit("Kirim Ucapan", ['class'=>'form_submit submit_button','id'=>'submit','name'=>'submit'])); ?>

                            <label id="loader" style="display:none;"><img src="<?php echo e(asset('wedding-1/images/loader.gif')); ?>" alt="Loading..." id="LoadingGraphic" /></label>
                      </form>
                    </div>
                </div>
            
                <ul class="features_list_detailed" id="wish" style="">
                    <?php $__currentLoopData = $wish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <li>
                            <div class="feat_small_details" >
                                <h4>
                                    <?php echo e($doa->nama); ?>

                                </h4>
                                <?php echo e($doa->wish); ?><br>
                                <span style="font-size: 10px;color: #aaaaaa;"><?php echo e(substr($doa->created_at, 0,10)); ?></span>
                            </div>
                        </li>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </ul>
                
            </div>
        
            <div class="page_single layout_fullwidth_padding" style="width: 100%;margin: 0px;padding-bottom: 32px;">
                <img src="<?php echo e(asset('wedding-1/images/headers/bottom/7.png')); ?>" alt="" width="100%" >
            </div>      
        </div>
        <?php echo $__env->make('wedding-1.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
    </div>
</div>