<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class wish extends Model
{
	protected $table	= "wish";
	protected $guarded 	= ['id'];
}
