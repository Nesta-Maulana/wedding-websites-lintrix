<div data-page="quotes" class="page no-toolbar no-navbar hidden" id="quotes">
    <div class="page-content">        
        <div id="pages_maincontent">
            <div class="page_single layout_fullwidth_padding" style="width: 100%;margin: 0px;text-align: center;" >
                <img src="<?php echo e(asset('wedding-1/images/headers/top/7.png')); ?>" alt="" width="100%" style="display: inline-block;"  >
            </div>
            <div id="sub_content" class="page_single layout_fullwidth_padding">
                <h2 class="page_title" style="">
                    <strong>Kata Mutiara</strong>
                </h2>
                <span>
                    &#34;Dan diantara tanda-tanda kekuasaan-Nya diciptakan-Nya untukmu pasangan hidup dari jenismu sendiri supaya kamu mendapat ketenangan hati dan dijadikan-Nya kasih sayang diantara kamu. Sesungguhnya yang demikian menjadi tanda-tanda kebesaran-Nya bagi orang-orang yang berfikir&#34; 
                    <br> 
                    <strong>[QS. Ar Ruum: 21]</strong>
                    <br>
                    <br>
                    &#34;Semoga Allah menghimpun yang terserak dari keduanya, memberkati mereka berdua, dan kiranya Allah meningkatkan kualitas keturunan mereka, menjadikannya pembuka pintu rahmat, sumber-sumber ilmu dan hikmah serta rasa aman bagi umat&#34; 
                    <br> 
                    <strong>
                        [Do`a Rasulullah SAW pada pernikahan putrinya Fatimah Az Zahra dangan Ali bin Abu Thalib]
                    </strong> 
                </span>          
            </div>
            <br>
            <div class="page_single layout_fullwidth_padding" style="width: 100%;margin: 0px;padding-bottom: 32px;">
                <img src="<?php echo e(asset('wedding-1/images/headers/bottom/7.png')); ?>" alt="" width="100%" >
            </div>      
        </div>
        <?php echo $__env->make('wedding-1.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
    </div>
</div>