<div data-page="team" class="page no-toolbar no-navbar hidden" id="couple">
    <div class="page-content">						
     	<div id="pages_maincontent">
      		<div class="page_single layout_fullwidth_padding" style="width: 100%;margin: 0px;text-align: center;" >
   				<img src="{{ asset('wedding-1/images/headers/top/7.png') }}" alt="" width="100%" style="display: inline-block;"  >
			</div>
			<div id="couple_content" class="page_single layout_fullwidth_padding" >  
	      		<span>
	      			<strong id="pre_greeting">
	      				Bismillahirrahmanirrahim</strong>
	      				<br>
					<strong>
						Assalamu`alaikum Warahmatullahi Wabarakatuh
					</strong> 
					<br>
						Dengan memohon rahmat serta ridho Allah Subhanahu Wa Ta`ala kami bermaksud menyelenggarakan acara pernikahan putra putri kami 	      		
				</span>

	      		<div class="swiper-container-team swiper-init" data-effect="slide" data-space-between="0" data-pagination=".swiper-pagination-teambigger" data-slides-per-view="1">			
					<div class="swiper-wrapper">
					  	<div id="brides" class="swiper-slide team-block">
						  	<a href="couple.htm#" data-view=".view-main"><img src="{{ asset('images/couples/wanita/6.jpg') }}" alt="" title="" /></a>
						  	<strong>
						  		Putri Marsella, S.H
						  	</strong>
						  		Putri Pertama dari Bpk. Tafiqulhadi Andianto, M.Si & Ibu Natasha Alfiah, S.Ak
					  	</div>
					</div>
		  		</div>
		  		<span id="dengan">
		  			<strong>dengan</strong> 
		  			<br>
		  		</span>
		  		<div class="swiper-container-team swiper-init" data-effect="slide" data-space-between="0" data-pagination=".swiper-pagination-teambigger" data-slides-per-view="1">			
					<div class="swiper-wrapper">
					  	<div id="brides" class="swiper-slide team-block">
						  	<a href="couple.htm#" data-view=".view-main">
						  		<img src="{{ asset('images/couples/pria/6.jpg') }}" alt="" title="" />
						  	</a>
						  	<strong>Andre Saputra, S.T</strong>
						  	Putra Pertama dari Bpk. Andre Ferdiansyah, M.Si & Ibu Dewi Ananda, S.Si					  	
					  	</div>
					</div>
				</div>		  		  
	        </div>
      		<div class="page_single layout_fullwidth_padding" style="width: 100%;margin: 0px;padding-bottom: 32px;">
   				<img src="{{ asset('wedding-1/images/headers/bottom/7.png') }}" alt="" width="100%" >
			</div>      	
		</div>
        @include('wedding-1.bottom')  
    </div>
</div>