<div data-page="contact" class="page no-toolbar no-navbar hidden" id="map">
    <div class="page-content">
        <div id="pages_maincontent">
            <div class="page_single layout_fullwidth_padding" style="width: 100%;margin: 0px;text-align: center;" >
                <img src="{{ asset('wedding-1/images/headers/top/7.png') }}" alt="" width="100%" style="display: inline-block;"  >
            </div>
            <div id="sub_content" class="page_single layout_fullwidth_padding" >
                <h2 class="page_title">
                    <strong>Lokasi</strong>
                </h2>	      
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3963.3341925229997!2d106.80621491431394!3d-6.605328716406258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69c5dd050ce619%3A0x7e7a919216349c5f!2sPuri+Begawan%2C+Baranangsiang%2C+Bogor+Tim.%2C+Kota+Bogor%2C+Jawa+Barat!5e0!3m2!1sid!2sid!4v1548727111265" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                
                <h3 id="video_name" class="page_subtitle"> </h3>
                <div class="clear"></div>
                <div class="clear"></div>   
            </div>
            <div class="page_single layout_fullwidth_padding" style="width: 100%;margin: 0px;padding-bottom: 32px;">
                <img src="{{ asset('wedding-1/images/headers/bottom/7.png') }}" alt="" width="100%" >
            </div>      
        </div>
        @include('wedding-1.bottom')  
    </div>
</div>